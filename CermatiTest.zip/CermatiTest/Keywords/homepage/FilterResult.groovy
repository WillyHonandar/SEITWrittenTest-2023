package homepage

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import internal.GlobalVariable
import pageobject.BaseWebObject

public class FilterResult extends BaseWebObject {

	private TestObject lblAppliedFilter
	private TestObject lblCondition
	private TestObject lblPrice
	private TestObject lblItemLocation

	public FilterResult() {
		super()
		lblAppliedFilter = createTestObjectByXpath("lblAppliedFilter", "//div[@id='s0-28-9-0-1[0]-0-1-6-9-4[0]-flyout']/button")
		lblCondition = createTestObjectByXpath("lblCondition", "//span[@class='brm__item-label' and contains(text(), 'Condition')]")
		lblPrice = createTestObjectByXpath("lblPrice", "//span[@class='brm__item-label' and contains(text(), 'Price')]")
		lblItemLocation = createTestObjectByXpath("lblItemLocation", "//span[@class='brm__item-label' and contains(text(), 'Item Location')]")
	}

	public void verifyAppliedFilter() {
		WebUI.verifyElementVisible(lblAppliedFilter)
	}

	public void verifyConition(String condition) {
		String actualText = WebUI.getText(lblCondition)
		KeywordUtil.logInfo(WebUI.getText(lblCondition))
		if(actualText.trim().contains(condition.trim())) {
			KeywordUtil.markPassed("Passed")
			
		}else {
			KeywordUtil.markFailed("Not Passed")
			
		}
	}

	public void verifyPrice(String minPrice, String maxPrice) {
		String expectedPrice = "Price: " + minPrice + ' to ' + maxPrice
		String actualPrice = WebUI.getText(lblPrice).trim()
		KeywordUtil.logInfo(actualPrice)
		KeywordUtil.logInfo(expectedPrice)
		//		WebUI.verifyElementText(actualPrice, expectedPrice)
	}
	//Untuk Price Saya skip karena waktu yang terbatas dikarenakan memerlukan logic tambahan

	public void verifyItemLocation(String itemLocation) {
		String actualText = WebUI.getText(lblItemLocation)
		KeywordUtil.logInfo(WebUI.getText(lblItemLocation))
		if(actualText.trim().contains(itemLocation.trim())) {
			KeywordUtil.markPassed("Passed")
			
		}else {
			KeywordUtil.markFailed("Not Passed")
			
		}
	}

	public void tapAppliedFilter() {
		WebUI.click(lblAppliedFilter)
	}
}
