package homepage

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import internal.GlobalVariable
import pageobject.BaseWebObject


public class HomePages extends BaseWebObject{
	private TestObject imgLogo
	private TestObject btnAllCategory
	private TestObject optionCategory
	private TestObject txfSearch
	private TestObject btnSearch

	public HomePages(String category = "") {
		super()
		btnAllCategory = createTestObjectByXpath("btnAllCategory", "//select[@id='gh-cat']")
		imgLogo = createTestObjectByXpath("imgLogo", "//select[@id='gh-cat']")
		optionCategory = createTestObjectByXpath("optionCategory", "//option[contains(text(), '$category')]")
		txfSearch = createTestObjectByXpath("txfSearch", "//input[@id='gh-ac']")
		btnSearch = createTestObjectByXpath("imgLogo", "//input[@id='gh-btn']")
	}

	public void verifyHome() {
		WebUI.verifyElementVisible(imgLogo)
	}

	public void tapAllCategory() {
		WebUI.click(btnAllCategory)
	}

	public void tapCategory() {
		WebUI.click(optionCategory)
	}

	public void tapSearch() {
		WebUI.click(btnSearch)
	}
	
	public void inputSearch(String search) {
		WebUI.setText(txfSearch, search)
	}
}