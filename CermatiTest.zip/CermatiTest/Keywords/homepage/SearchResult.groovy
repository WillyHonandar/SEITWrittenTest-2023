package homepage

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import internal.GlobalVariable
import pageobject.BaseWebObject

public class SearchResult extends BaseWebObject{
	private TestObject lblFirstProductTitle
	public SearchResult() {
		super()
		
		lblFirstProductTitle = createTestObjectByXpath("lblFirstProductTitle", "//ul[@class='srp-results srp-list clearfix']/li[1]/div/div[2]/a/div/span")
	}
	
//	def static boolean isContains(String actualText, String expectedText) {
//		if(!actualText) actualText = ""
//		if(actualText.trim().contains(expectedText.trim())) {
//			KeywordUtil.markPassed("MobileHelpers: isContains: expected text: '$expectedText' IS included in actual text: '$actualText'")
//			return true
//		}else {
//			KeywordUtil.markFailed("MobileHelpers: isContains: expected text: '$expectedText' is NOT included in actual text: '$actualText'")
//			return false
//		}
//	}
	
	

	
	public boolean verifyFirstProduct(String expectedText) {
		String actualText = WebUI.getText(lblFirstProductTitle)
		KeywordUtil.logInfo(WebUI.getText(lblFirstProductTitle))
		if(actualText.trim().contains(expectedText.trim())) {
			KeywordUtil.markPassed("Passed")
		}else {
			KeywordUtil.markFailed("Not Passed")
		}
	}
}
