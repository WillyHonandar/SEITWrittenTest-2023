package homepage

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

import internal.GlobalVariable
import pageobject.BaseWebObject

public class AllFilters extends BaseWebObject{
	private TestObject lblFilterCount
	private TestObject btnCondition
	private TestObject btnPrice
	private TestObject btnItemLocation


	private TestObject checkBoxCondition

	private TestObject txtMinValue
	private TestObject txtMaxValue

	private TestObject radioItemLocation
	private TestObject btnApply

	public AllFilters(String condition = "",  String itemLocation = "") {
		super()
		lblFilterCount = createTestObjectByXpath("lblFilterCount", "//div[@id='innerlayer']/button/span")
		btnCondition = createTestObjectByXpath("btnCondition", "//div[@id='c3-mainPanel-condition']")
		btnPrice = createTestObjectByXpath("btnPrice", "//div[@id='c3-mainPanel-price']")
		btnItemLocation = createTestObjectByXpath("btnItemLocation", "//div[@id='c3-mainPanel-location']")
		checkBoxCondition = createTestObjectByXpath("checkBoxCondition", "//div[@class='x-refine__multi-select x-overlay-sub-panel__aspect-option'  and contains(@id, '$condition')]/span[1]")

		txtMinValue = createTestObjectByXpath("txtMinValue", "//input[@class='x-textrange__input x-textrange__input--from']")
		txtMaxValue = createTestObjectByXpath("txtMaxValue", "//input[@class='x-textrange__input x-textrange__input--to']")
		radioItemLocation = createTestObjectByXpath("radioItemLocation", "//span[@class='radio field__control rbx x-refine__single-select-radio']/input[@value = '$itemLocation']")
		btnApply = createTestObjectByXpath("btnApply", "// button[@class='x-overlay-footer__apply-btn btn btn--primary']")
	}

	public void verifyAllFilters() {
		WebUI.verifyElementVisible(lblFilterCount)
	}

	public void chooseCondition() {
		//		WebUI.scrollToElement(btnCondition, 30, FailureHandling.STOP_ON_FAILURE)
		WebUI.click(btnCondition)
		WebUI.click(checkBoxCondition)
	}

	public void setPrice(String minPrice, String maxPrice) {
		//		WebUI.scrollToElement(btnPrice, 30, FailureHandling.STOP_ON_FAILURE)
		WebUI.click(btnPrice)
		WebUI.setText(txtMinValue, minPrice)
		WebUI.setText(txtMaxValue, maxPrice)
	}

	public void chooseItemLocation() {
		//		WebUI.scrollToElement(btnCondition, 30, FailureHandling.STOP_ON_FAILURE)
		WebUI.click(btnItemLocation)
		WebUI.click(radioItemLocation)
	}

	public void tapApply() {
		WebUI.click(btnApply)
	}
}
